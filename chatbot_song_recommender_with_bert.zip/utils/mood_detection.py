from transformers import pipeline

# Load pre-trained sentiment-analysis pipeline (BERT)
classifier = pipeline("sentiment-analysis")

def detect_mood(text):
    result = classifier(text)[0]
    label = result["label"]

    if label == "POSITIVE":
        return "happy"
    elif label == "NEGATIVE":
        return "sad"
    else:
        return "relaxed"  # Default fallback
