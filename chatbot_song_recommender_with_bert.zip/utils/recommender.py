def recommend_song(mood, history):
    songs = {
        "happy": ["Happy by Pharrell", "Best Day of My Life - American Authors"],
        "sad": ["Someone Like You - Adele", "Let Her Go - Passenger"],
        "angry": ["Stronger - Kanye West", "Numb - Linkin Park"],
        "relaxed": ["Weightless - Marconi Union", "Let It Be - The Beatles"]
    }
    for song in songs.get(mood, []):
        if song not in history:
            return song
    return "No new recommendations. Try again later."
